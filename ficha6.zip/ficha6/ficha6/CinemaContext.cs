﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace ficha6
{
    internal class CinemaContext : DbContext
    { 
        public CinemaContext() : base("CinemaContext")
        {

        }
        public DbSet<Filme> Filmes { get; set; }
        public DbSet<Utilizador> Utilizadores { get; set; }
        public DbSet<ComprarFilmes> ComprarFilmes { get; set; }
        public DbSet<OrcamentoMensal> OrcamentosMensais { get; set; }
    }
}
