﻿namespace ficha6
{
    public partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTitulo = new System.Windows.Forms.Label();
            this.labelGenero = new System.Windows.Forms.Label();
            this.labelAno = new System.Windows.Forms.Label();
            this.labelId = new System.Windows.Forms.Label();
            this.textBoxAno = new System.Windows.Forms.TextBox();
            this.textBoxGeneroFilme = new System.Windows.Forms.TextBox();
            this.textBoxTituloFilme = new System.Windows.Forms.TextBox();
            this.textBoxId = new System.Windows.Forms.TextBox();
            this.buttonAdicionar = new System.Windows.Forms.Button();
            this.buttonAtualizar = new System.Windows.Forms.Button();
            this.buttonRemover = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.buttonExportar = new System.Windows.Forms.Button();
            this.buttonComprasEstatisticas = new System.Windows.Forms.Button();
            this.buttonSair = new System.Windows.Forms.Button();
            this.labelVisualizações = new System.Windows.Forms.Label();
            this.textBoxVisualizaçoes = new System.Windows.Forms.TextBox();
            this.labelRealizador = new System.Windows.Forms.Label();
            this.textBoxRealizador = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTitulo
            // 
            this.labelTitulo.AutoSize = true;
            this.labelTitulo.Location = new System.Drawing.Point(47, 76);
            this.labelTitulo.Name = "labelTitulo";
            this.labelTitulo.Size = new System.Drawing.Size(98, 16);
            this.labelTitulo.TabIndex = 0;
            this.labelTitulo.Text = "Titulo do Filme:";
            // 
            // labelGenero
            // 
            this.labelGenero.AutoSize = true;
            this.labelGenero.Location = new System.Drawing.Point(47, 117);
            this.labelGenero.Name = "labelGenero";
            this.labelGenero.Size = new System.Drawing.Size(105, 16);
            this.labelGenero.TabIndex = 1;
            this.labelGenero.Text = "Género do filme:";
            // 
            // labelAno
            // 
            this.labelAno.AutoSize = true;
            this.labelAno.Location = new System.Drawing.Point(47, 168);
            this.labelAno.Name = "labelAno";
            this.labelAno.Size = new System.Drawing.Size(34, 16);
            this.labelAno.TabIndex = 2;
            this.labelAno.Text = "Ano:";
            // 
            // labelId
            // 
            this.labelId.AutoSize = true;
            this.labelId.Location = new System.Drawing.Point(311, 169);
            this.labelId.Name = "labelId";
            this.labelId.Size = new System.Drawing.Size(21, 16);
            this.labelId.TabIndex = 3;
            this.labelId.Text = "Id:";
            // 
            // textBoxAno
            // 
            this.textBoxAno.Location = new System.Drawing.Point(164, 162);
            this.textBoxAno.Name = "textBoxAno";
            this.textBoxAno.Size = new System.Drawing.Size(115, 22);
            this.textBoxAno.TabIndex = 4;
            // 
            // textBoxGeneroFilme
            // 
            this.textBoxGeneroFilme.Location = new System.Drawing.Point(164, 111);
            this.textBoxGeneroFilme.Name = "textBoxGeneroFilme";
            this.textBoxGeneroFilme.Size = new System.Drawing.Size(115, 22);
            this.textBoxGeneroFilme.TabIndex = 5;
            // 
            // textBoxTituloFilme
            // 
            this.textBoxTituloFilme.Location = new System.Drawing.Point(164, 70);
            this.textBoxTituloFilme.Name = "textBoxTituloFilme";
            this.textBoxTituloFilme.Size = new System.Drawing.Size(316, 22);
            this.textBoxTituloFilme.TabIndex = 6;
            // 
            // textBoxId
            // 
            this.textBoxId.Location = new System.Drawing.Point(360, 162);
            this.textBoxId.Name = "textBoxId";
            this.textBoxId.Size = new System.Drawing.Size(120, 22);
            this.textBoxId.TabIndex = 7;
            // 
            // buttonAdicionar
            // 
            this.buttonAdicionar.Location = new System.Drawing.Point(522, 69);
            this.buttonAdicionar.Name = "buttonAdicionar";
            this.buttonAdicionar.Size = new System.Drawing.Size(165, 23);
            this.buttonAdicionar.TabIndex = 8;
            this.buttonAdicionar.Text = "Adicionar";
            this.buttonAdicionar.UseVisualStyleBackColor = true;
            this.buttonAdicionar.Click += new System.EventHandler(this.buttonAdicionar_Click);
            // 
            // buttonAtualizar
            // 
            this.buttonAtualizar.Location = new System.Drawing.Point(522, 162);
            this.buttonAtualizar.Name = "buttonAtualizar";
            this.buttonAtualizar.Size = new System.Drawing.Size(165, 23);
            this.buttonAtualizar.TabIndex = 9;
            this.buttonAtualizar.Text = "Atualizar";
            this.buttonAtualizar.UseVisualStyleBackColor = true;
            this.buttonAtualizar.Click += new System.EventHandler(this.buttonAtualizar_Click);
            // 
            // buttonRemover
            // 
            this.buttonRemover.Location = new System.Drawing.Point(522, 114);
            this.buttonRemover.Name = "buttonRemover";
            this.buttonRemover.Size = new System.Drawing.Size(165, 23);
            this.buttonRemover.TabIndex = 10;
            this.buttonRemover.Text = "Remover";
            this.buttonRemover.UseVisualStyleBackColor = true;
            this.buttonRemover.Click += new System.EventHandler(this.buttonRemover_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(50, 221);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(869, 264);
            this.dataGridView1.TabIndex = 11;
            // 
            // buttonExportar
            // 
            this.buttonExportar.Location = new System.Drawing.Point(754, 114);
            this.buttonExportar.Name = "buttonExportar";
            this.buttonExportar.Size = new System.Drawing.Size(165, 23);
            this.buttonExportar.TabIndex = 12;
            this.buttonExportar.Text = "Exportar CSV";
            this.buttonExportar.UseVisualStyleBackColor = true;
            // 
            // buttonComprasEstatisticas
            // 
            this.buttonComprasEstatisticas.Location = new System.Drawing.Point(754, 69);
            this.buttonComprasEstatisticas.Name = "buttonComprasEstatisticas";
            this.buttonComprasEstatisticas.Size = new System.Drawing.Size(165, 23);
            this.buttonComprasEstatisticas.TabIndex = 13;
            this.buttonComprasEstatisticas.Text = "Compras e Estatisticas";
            this.buttonComprasEstatisticas.UseVisualStyleBackColor = true;
            // 
            // buttonSair
            // 
            this.buttonSair.Location = new System.Drawing.Point(754, 165);
            this.buttonSair.Name = "buttonSair";
            this.buttonSair.Size = new System.Drawing.Size(165, 23);
            this.buttonSair.TabIndex = 14;
            this.buttonSair.Text = "Sair";
            this.buttonSair.UseVisualStyleBackColor = true;
            // 
            // labelVisualizações
            // 
            this.labelVisualizações.AutoSize = true;
            this.labelVisualizações.Location = new System.Drawing.Point(296, 114);
            this.labelVisualizações.Name = "labelVisualizações";
            this.labelVisualizações.Size = new System.Drawing.Size(104, 16);
            this.labelVisualizações.TabIndex = 15;
            this.labelVisualizações.Text = "Nºvisualizações";
            // 
            // textBoxVisualizaçoes
            // 
            this.textBoxVisualizaçoes.Location = new System.Drawing.Point(406, 112);
            this.textBoxVisualizaçoes.Name = "textBoxVisualizaçoes";
            this.textBoxVisualizaçoes.Size = new System.Drawing.Size(74, 22);
            this.textBoxVisualizaçoes.TabIndex = 16;
            // 
            // labelRealizador
            // 
            this.labelRealizador.AutoSize = true;
            this.labelRealizador.Location = new System.Drawing.Point(47, 27);
            this.labelRealizador.Name = "labelRealizador";
            this.labelRealizador.Size = new System.Drawing.Size(73, 16);
            this.labelRealizador.TabIndex = 17;
            this.labelRealizador.Text = "Realizador";
            // 
            // textBoxRealizador
            // 
            this.textBoxRealizador.Location = new System.Drawing.Point(147, 27);
            this.textBoxRealizador.Name = "textBoxRealizador";
            this.textBoxRealizador.Size = new System.Drawing.Size(100, 22);
            this.textBoxRealizador.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1136, 497);
            this.Controls.Add(this.textBoxRealizador);
            this.Controls.Add(this.labelRealizador);
            this.Controls.Add(this.textBoxVisualizaçoes);
            this.Controls.Add(this.labelVisualizações);
            this.Controls.Add(this.buttonSair);
            this.Controls.Add(this.buttonComprasEstatisticas);
            this.Controls.Add(this.buttonExportar);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.buttonRemover);
            this.Controls.Add(this.buttonAtualizar);
            this.Controls.Add(this.buttonAdicionar);
            this.Controls.Add(this.textBoxId);
            this.Controls.Add(this.textBoxTituloFilme);
            this.Controls.Add(this.textBoxGeneroFilme);
            this.Controls.Add(this.textBoxAno);
            this.Controls.Add(this.labelId);
            this.Controls.Add(this.labelAno);
            this.Controls.Add(this.labelGenero);
            this.Controls.Add(this.labelTitulo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTitulo;
        private System.Windows.Forms.Label labelGenero;
        private System.Windows.Forms.Label labelAno;
        private System.Windows.Forms.Label labelId;
        private System.Windows.Forms.TextBox textBoxAno;
        private System.Windows.Forms.TextBox textBoxGeneroFilme;
        private System.Windows.Forms.TextBox textBoxTituloFilme;
        private System.Windows.Forms.TextBox textBoxId;
        private System.Windows.Forms.Button buttonAdicionar;
        private System.Windows.Forms.Button buttonAtualizar;
        private System.Windows.Forms.Button buttonRemover;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonExportar;
        private System.Windows.Forms.Button buttonComprasEstatisticas;
        private System.Windows.Forms.Button buttonSair;
        private System.Windows.Forms.Label labelVisualizações;
        private System.Windows.Forms.TextBox textBoxVisualizaçoes;
        private System.Windows.Forms.Label labelRealizador;
        private System.Windows.Forms.TextBox textBoxRealizador;
    }
}

