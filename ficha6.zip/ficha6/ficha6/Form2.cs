﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ficha6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void buttonEntrar_Click(object sender, EventArgs e)
        {
            string login = textBoxUsername.Text.Trim();
            string password = textBoxPassword.Text;

            if (login == "" || password == "")
            {
                MessageBox.Show("Preencha todos os campos.");
                return;
            }

            using (CinemaContext db = new CinemaContext())
            {
                Utilizador utilizador = db.Utilizadores.FirstOrDefault(u => u.Username == login && u.Password == password);
                if (utilizador != null)
                {
                    Sessao.UtilizadorAtual = utilizador.Username;
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
        }
    }
}
