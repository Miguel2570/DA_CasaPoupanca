﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ficha6
{
    internal class Filme
    {
        public Filme() 
        {
           Compras = new List<ComprarFilmes>();
        }
        public int Id { get; set; }
        public string Titulo { get; set; }
        public string Genero { get; set; }
        public int Ano { get; set; }
        public string Realizador { get; set; }

        public DateTime? DataHoraAlteracao { get; set; }
        public string AlteradoPor { get; set; }
        public int VezesVisto { get; set; }
        public virtual ICollection<ComprarFilmes> Compras { get; set; }



    }
}
