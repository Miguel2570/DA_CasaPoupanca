﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ficha6
{
    internal static class Sessao
    {
        public static string UtilizadorAtual { get; set; }
    }
}
