﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace ficha6
{
    public partial class Form1 : Form
    {
        private CinemaContext db;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.RowHeadersWidth = 60;

            dataGridView1.ClearSelection();


            //db = new CinemaContext(); //new CinemaContext() abre o acesso à base de dados;
            //db.Filmes.Load();//db.Filmes.Load() lê os filmes guardados;
            //dataGridView1.DataSource = db.Filmes.Local.ToBindingList();//DataSource = ... mostra esses filmes na tabela do formulário.
        }

        private void AtualizarGrelha()
        {
           using (CinemaContext db = new CinemaContext())
            {
                dataGridView1.DataSource = db.Filmes.OrderBy(f=>f.Titulo).ToList();
            }

           if (dataGridView1.Columns["DataHoraAlteracao"] != null)
            {
                dataGridView1.Columns["DataHoraAlteracao"].HeaderText = "Data / Hora da alteração";
                dataGridView1.Columns["DataHoraAlteracao"].DefaultCellStyle.Format = "dd/MM/yyyy HH:mm:ss";
            }
            if (dataGridView1.Columns["AlteradoPor"] != null)
            {
                dataGridView1.Columns["AlteradoPor"].HeaderText = "Alterado por";
            }

            if (dataGridView1.Columns["VezesVisto"] != null)
            {
                dataGridView1.Columns["VezesVisto"].HeaderText = "N. de visualizações";
            }
        }

        private void LimparCampos()
        {
            textBoxTituloFilme.Text = "";
            textBoxGeneroFilme.Text = "";
            textBoxAno.Text = "";
            textBoxId.Text = "";
            textBoxRealizador.Text = "";
            dataGridView1.ClearSelection();               
        }

        private bool ValidarDados(out int ano, out int vezesVisto)
        {
            ano = 0;
            vezesVisto = 0;

            if (textBoxTituloFilme.Text.Trim() == "" ||
                textBoxGeneroFilme.Text.Trim() == "" ||
                textBoxAno.Text.Trim() == "" ||
                textBoxVisualizaçoes.Text.Trim() == ""||
                textBoxRealizador.Text.Trim() == "")
            {
                MessageBox.Show("Preencha todos os campos.");
                return false;
            }

            if (!int.TryParse(textBoxAno.Text, out ano))
            {
                MessageBox.Show("O ano tem de ser numérico.");
                return false;
            }

            if (!int.TryParse(textBoxVisualizaçoes.Text, out vezesVisto))
            {
                MessageBox.Show("O número de visualizações tem de ser numérico.");
                return false;
            }

            if (vezesVisto < 0)
            {
                MessageBox.Show("Não pode ser negativo.");
                return false;
            }

            return true;
        }
        private bool FilmeRepetido(CinemaContext db, string titulo, string genero, int ano, string realizador, int? idIgnorar = null)
        {
            return db.Filmes.Any(f =>
                f.Titulo == titulo &&
                f.Genero == genero &&
                f.Ano == ano &&
                f.Realizador == realizador &&
                (!idIgnorar.HasValue || f.Id != idIgnorar.Value));
        }

        private void buttonAdicionar_Click(object sender, EventArgs e)
        {
            int ano;
            int vezesVisto;

            if (!ValidarDados(out ano, out vezesVisto))
            {
                return;
            }               

            string titulo = textBoxTituloFilme.Text.Trim();
            string genero = textBoxGeneroFilme.Text.Trim();
            string realizador = textBoxRealizador.Text.Trim();

            using (CinemaContext db = new CinemaContext())
            {
                if (FilmeRepetido(db, titulo, genero, ano, realizador))
                {
                    MessageBox.Show("Esse filme já existe.");
                    return;
                }

                Filme filme = new Filme
                {
                    Titulo = titulo,
                    Genero = genero,
                    Ano = ano,
                    Realizador = realizador,
                    VezesVisto = vezesVisto,
                    DataHoraAlteracao = DateTime.Now,
                    AlteradoPor = "Utilizador"
                };

                db.Filmes.Add(filme);
                db.SaveChanges();
            }

            MessageBox.Show("Filme guardado com sucesso.");
            AtualizarGrelha();
            LimparCampos();
        }
        

      
        private void dataGridView1_SelectionChanged (object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow != null && dataGridView1.CurrentRow.DataBoundItem != null) //dataGridView1.CurrentRow.DataBoundItem devolve o objeto que está ligado à linha selecionada; esse objeto está armazenado de forma genérica;
            {
                Filme filmeSelecionado = (Filme)dataGridView1.CurrentRow.DataBoundItem;// por isso, faz-se um cast para o tipo Filme, usando (Filme). Desta forma, a variável filmeSelecionado passa a representar o filme correspondente à linha escolhida no DataGridView.


                textBoxId.Text = filmeSelecionado.Id.ToString();
                textBoxTituloFilme.Text = filmeSelecionado.Titulo;
                textBoxGeneroFilme.Text = filmeSelecionado.Genero;
                textBoxAno.Text = filmeSelecionado.Ano.ToString();
                textBoxRealizador.Text = filmeSelecionado.Realizador;
            }

        }

        private void buttonRemover_Click(object sender, EventArgs e)
        {
            if (textBoxId.Text.Trim() == "")
            {
                MessageBox.Show("Indique o ID do filme.");
                return;
            }

            int id;
            if (!int.TryParse(textBoxId.Text, out id))
            {
                MessageBox.Show("O ID tem de ser numérico.");
                return;
            }

            Filme filme = db.Filmes.Find(id);

            if (filme == null)
            {
                MessageBox.Show("Não existe nenhum filme com esse ID.");
                return;
            }

            db.Filmes.Remove(filme);
            db.SaveChanges();

            MessageBox.Show("Filme eleminado com sucesso.");
            LimparCampos();
        }

        private void buttonAtualizar_Click(object sender, EventArgs e)
        {
            if(textBoxId.Text.Trim() == "")
            {
                MessageBox.Show("Indique o ID do filme.");
                return;
            }

            int id;
            if(!int.TryParse(textBoxId.Text, out id))
            {
                MessageBox.Show("O ID tem de ser numérico.");
                return;
            }

            int ano;
            int vezesVisto;

            if (!ValidarDados(out ano, out vezesVisto))
            {
                return;
            }

            string titulo = textBoxTituloFilme.Text.Trim();
            string genero = textBoxGeneroFilme.Text.Trim();
            string realizador = textBoxRealizador.Text.Trim();

            using (CinemaContext db = new CinemaContext())
            {
                Filme filme = db.Filmes.Find(id);

                if (filme == null)
                {
                    MessageBox.Show("Não existe nenhum filme com esse ID.");
                    return;
                }

                if (FilmeRepetido(db, titulo, genero, ano, realizador, id))
                {
                    MessageBox.Show("Já existe outro filme com os mesmos dados.");
                    return;
                }

                filme.Titulo = titulo;
                filme.Genero = genero;
                filme.Ano = ano;
                filme.Realizador = realizador;
                filme.VezesVisto = vezesVisto;
                filme.DataHoraAlteracao = DateTime.Now;
                filme.AlteradoPor = Sessao.UtilizadorAtual;

                db.SaveChanges();
            }

            MessageBox.Show("Filme atualizado com sucesso.");
            AtualizarGrelha();
            LimparCampos();
        }


        private void Form1_FormClosed (object sender, FormClosedEventArgs e)
        {
            if(db != null)// Esta condição verifica se a variável db foi criada. Se a condição não existir, não faz sentido tentar fechá - la ou libertá-la
            {  
                db.Dispose(); //O método Dispose() é utilizado para libertar os recursos ocupados pelo objeto db, isto é, termina corretamente a utilização da base de dados, liberta a memória e outros recursos associados à ligação.
            }
        }

        
    }
}
