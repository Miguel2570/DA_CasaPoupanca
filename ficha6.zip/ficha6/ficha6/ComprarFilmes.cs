﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ficha6
{
    internal class ComprarFilmes
    {
        public int Id { get; set; }
        public int FilmeId { get; set; }
        public decimal PrecoCompra { get; set; }
        public decimal IMDb { get; set; }
        public DateTime DataCompra { get; set; }

        public virtual Filme Filme { get; set; }
    }
}
