﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace ficha6
{
    internal class AppDbInitializer : DropCreateDatabaseIfModelChanges<CinemaContext>
    {
        protected override void Seed(CinemaContext context)
        {
            context.Utilizadores.Add(new Utilizador
            {
                Username = "admin",
                Password = "1234"
            });

            context.Utilizadores.Add(new Utilizador
            {
                Username = "Pedro",
                Password = "abcd"
            });

            context.Filmes.Add(new Filme
            {
                Titulo = "Matrix",
                Genero = "Ficção Científica",
                Ano = 1999,
                DataHoraAlteracao = DateTime.Now,
                AlteradoPor = "Sistema",
                VezesVisto = 2
            });

            context.Filmes.Add(new Filme
            {
                Titulo = "Titanic",
                Genero = "Romance",
                Ano = 1997,
                DataHoraAlteracao = DateTime.Now,
                AlteradoPor = "Sistema",
                VezesVisto = 1
            });

            context.Filmes.Add(new Filme
            {
                Titulo = "Gladiador",
                Genero = "Ação",
                Ano = 2000,
                DataHoraAlteracao = DateTime.Now,
                AlteradoPor = "Sistema",
                VezesVisto = 3
            });

            base.Seed(context);

            int mesAtual = DateTime.Today.Month;
            int anoAtual = DateTime.Today.Year;

            Filme matrix = context.Filmes.FirstOrDefault(f => f.Titulo == "Matrix");
            Filme titanic = context.Filmes.FirstOrDefault(f => f.Titulo == "Titanic");  
            Filme gladiador = context.Filmes.FirstOrDefault(f => f.Titulo == "Gladiador");

            if (matrix != null)
            {
                context.ComprarFilmes.Add(new ComprarFilmes
                {
                    FilmeId = matrix.Id,
                    PrecoCompra = 9.99m,
                    IMDb = 8.7m,
                    DataCompra = new DateTime(anoAtual, mesAtual, 5)
                });
          
            }
            if (titanic != null)
            {
                context.ComprarFilmes.Add(new ComprarFilmes
                {
                    FilmeId = titanic.Id,
                    PrecoCompra = 7.50m,
                    IMDb = 7.9m,
                    DataCompra = new DateTime(anoAtual, mesAtual, 12)
                });

            }
            if (gladiador != null)
            {
                context.ComprarFilmes.Add(new ComprarFilmes
                {
                    FilmeId = gladiador.Id,
                    PrecoCompra = 8.20m,
                    IMDb = 8.5m,
                    DataCompra = new DateTime(anoAtual, mesAtual, 20)
                });

            }

            context.OrcamentosMensais.Add(new OrcamentoMensal
            {
                Mes = mesAtual,
                Ano = anoAtual,
                ValorOrcamento = 50.00m
            });
            base.Seed(context);
        }
    }
}
