﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CineDBteste.Model
{
    internal class OrcamentoMensal
    {

        public int Id {  get; set; }
        public int Mes {  get; set; }
        public int Ano {  get; set; }
        public decimal ValorOrcamento {get; set; }

    }
}
