﻿using CineDBteste.Model;
using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace CineDBteste
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            dgvCompras.AutoGenerateColumns = true;

            txtMes.Text = DateTime.Today.Month.ToString();
            txtAnoOrcamento.Text = DateTime.Today.Year.ToString();

            AtualizarCompras();
            AtualizarEstatisticas();
        }

        private void AtualizarCompras()
        {
            using (CinemaContext db = new CinemaContext())
            {
                dgvCompras.DataSource = null;
                dgvCompras.DataSource = db.ComprarFilmes
                    .OrderByDescending(c => c.DataCompra)
                    .Select(c => new
                    {
                        c.Id,
                        Titulo = c.Filme.Titulo,
                        c.PrecoCompra,
                        c.NotaIMDb,
                        c.DataCompra
                    })
                    .ToList();
            }
        }

        private void btnGuardarCompra_Click(object sender, EventArgs e)
        {
            if (txtNomeFilme.Text.Trim() == "")
            {
                MessageBox.Show("Indique o nome do filme.");
                return;
            }

            decimal preco;
            decimal nota;

            if (!decimal.TryParse(txtPrecoCompra.Text, out preco))
            {
                MessageBox.Show("O preço tem de ser numérico.");
                return;
            }

            if (!decimal.TryParse(txtIMDb.Text, out nota))
            {
                MessageBox.Show("A classificação IMDb tem de ser numérica.");
                return;
            }

            if (nota < 0 || nota > 10)
            {
                MessageBox.Show("A classificação IMDb deve estar entre 0 e 10.");
                return;
            }

            string nomeFilme = txtNomeFilme.Text.Trim();

            using (CinemaContext db = new CinemaContext())
            {
                Filmecs filme = db.Filmes
                    .FirstOrDefault(f => f.Titulo == nomeFilme);

                if (filme == null)
                {
                    filme = new Filmecs
                    {
                        Titulo = nomeFilme,
                        Genero = "Não definido",
                        Ano = DateTime.Today.Year,
                        Realizador = "Desconhecido",
                        VezesVisto = 0,
                        DataHoraAlteracao = DateTime.Now,
                        AlteradoPor = Sessao.UtilizadorAtual
                    };

                    db.Filmes.Add(filme);
                    db.SaveChanges();
                }

                ComprarFilme compra = new ComprarFilme
                {
                    FilmeId = filme.Id,
                    PrecoCompra = preco,
                    NotaIMDb = nota,
                    DataCompra = dtpDataCompra.Value.Date
                };

                db.ComprarFilmes.Add(compra);
                db.SaveChanges();
            }

            MessageBox.Show("Compra registada com sucesso.");
            AtualizarCompras();
            AtualizarEstatisticas();

            txtNomeFilme.Text = "";
            txtPrecoCompra.Text = "";
            txtIMDb.Text = "";
        }

        private void btnGuardarOrcamento_Click(object sender, EventArgs e)
        {
            int mes;
            int ano;
            decimal valor;

            if (!int.TryParse(txtMes.Text, out mes))
            {
                MessageBox.Show("O mês tem de ser numérico.");
                return;
            }

            if (!int.TryParse(txtAnoOrcamento.Text, out ano))
            {
                MessageBox.Show("O ano tem de ser numérico.");
                return;
            }

            if (!decimal.TryParse(txtValorOrcamento.Text, out valor))
            {
                MessageBox.Show("O valor do orçamento tem de ser numérico.");
                return;
            }

            using (CinemaContext db = new CinemaContext())
            {
                OrcamentoMensal orcamento = db.OrcamentosMensais
                    .FirstOrDefault(o => o.Mes == mes && o.Ano == ano);

                if (orcamento == null)
                {
                    orcamento = new OrcamentoMensal
                    {
                        Mes = mes,
                        Ano = ano,
                        ValorOrcamento = valor
                    };

                    db.OrcamentosMensais.Add(orcamento);
                }
                else
                {
                    orcamento.ValorOrcamento = valor;
                }

                db.SaveChanges();
            }

            MessageBox.Show("Orçamento guardado com sucesso.");
            AtualizarEstatisticas();
        }

        private void btnAtualizarEstatisticas_Click(object sender, EventArgs e)
        {
            AtualizarEstatisticas();

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Ficheiros CSV (*.csv)|*.csv";
            sfd.Title = "Guardar estatísticas em CSV";
            sfd.FileName = "estatisticas_filmes.csv";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                ExportarEstatisticasCsv(sfd.FileName);
                MessageBox.Show("Estatísticas exportadas com sucesso.");
            }
        }

        private void AtualizarEstatisticas()
        {
            int mes;
            int ano;

            if (!int.TryParse(txtMes.Text, out mes))
            {
                mes = DateTime.Today.Month;
            }

            if (!int.TryParse(txtAnoOrcamento.Text, out ano))
            {
                ano = DateTime.Today.Year;
            }

            using (CinemaContext db = new CinemaContext())
            {
                int totalFilmes = db.Filmes.Count();
                lblTotalFilmes.Text = "Total de filmes: " + totalFilmes;

                var comprasMes = db.ComprarFilmes
                    .Where(c => c.DataCompra.Month == mes && c.DataCompra.Year == ano);

                decimal totalGasto = 0m;
                if (comprasMes.Any())
                {
                    totalGasto = comprasMes.Sum(c => c.PrecoCompra);
                }

                lblTotalGasto.Text = "Total gasto: " + totalGasto.ToString("0.00") + " €";

                OrcamentoMensal orcamento = db.OrcamentosMensais
                    .FirstOrDefault(o => o.Mes == mes && o.Ano == ano);

                decimal valorOrcamento = 0m;
                if (orcamento != null)
                {
                    valorOrcamento = orcamento.ValorOrcamento;
                }

                decimal saldo = valorOrcamento - totalGasto;
                lblSaldo.Text = "Saldo disponível: " + saldo.ToString("0.00") + " €";

                decimal precoMedio = 0m;
                if (comprasMes.Any())
                {
                    precoMedio = comprasMes.Average(c => c.PrecoCompra);
                }

                lblPrecoMedio.Text = "Preço médio: " + precoMedio.ToString("0.00") + " €";

                var melhorIMDb = db.ComprarFilmes
                    .OrderByDescending(c => c.NotaIMDb)
                    .Select(c => new
                    {
                        Titulo = c.Filme.Titulo,
                        c.NotaIMDb
                    })
                    .FirstOrDefault();

                if (melhorIMDb != null)
                {
                    blMelhorIMDb.Text = "Melhor IMDb: " + melhorIMDb.Titulo + " (" + melhorIMDb.NotaIMDb.ToString("0.0") + ")";
                }
                else
                {
                    blMelhorIMDb.Text = "Melhor IMDb: sem dados";
                }

                var topFilmes = db.Filmes
                    .OrderByDescending(f => f.VezesVisto)
                    .ThenBy(f => f.Titulo)
                    .Take(5)
                    .ToList();

                lstTopFilmes.Items.Clear();
                foreach (Filmecs f in topFilmes)
                {
                    lstTopFilmes.Items.Add(f.Titulo + " - " + f.VezesVisto + " visualizações");
                }

                var filmesPorGenero =
                    from f in db.Filmes
                    group f by f.Genero into grupo
                    orderby grupo.Key
                    select new
                    {
                        Genero = grupo.Key,
                        Total = grupo.Count()
                    };

                lstFilmesPorGenero.Items.Clear();
                foreach (var item in filmesPorGenero.ToList())
                {
                    lstFilmesPorGenero.Items.Add(item.Genero + ": " + item.Total);
                }
            }
        }

        private void ExportarEstatisticasCsv(string caminho)
        {
            int mes;
            int ano;

            if (!int.TryParse(txtMes.Text, out mes))
            {
                mes = DateTime.Today.Month;
            }

            if (!int.TryParse(txtAnoOrcamento.Text, out ano))
            {
                ano = DateTime.Today.Year;
            }

            using (CinemaContext db = new CinemaContext())
            {
                int totalFilmes = db.Filmes.Count();

                var comprasMes = db.ComprarFilmes
                    .Where(c => c.DataCompra.Month == mes && c.DataCompra.Year == ano);

                decimal totalGasto = 0m;
                if (comprasMes.Any())
                {
                    totalGasto = comprasMes.Sum(c => c.PrecoCompra);
                }

                OrcamentoMensal orcamento = db.OrcamentosMensais
                    .FirstOrDefault(o => o.Mes == mes && o.Ano == ano);

                decimal valorOrcamento = 0m;
                if (orcamento != null)
                {
                    valorOrcamento = orcamento.ValorOrcamento;
                }

                decimal saldo = valorOrcamento - totalGasto;

                decimal precoMedio = 0m;
                if (comprasMes.Any())
                {
                    precoMedio = comprasMes.Average(c => c.PrecoCompra);
                }

                var melhorIMDb = db.ComprarFilmes
                    .OrderByDescending(c => c.NotaIMDb)
                    .Select(c => new
                    {
                        Titulo = c.Filme.Titulo,
                        c.NotaIMDb
                    })
                    .FirstOrDefault();

                var topFilmes = db.Filmes
                    .OrderByDescending(f => f.VezesVisto)
                    .ThenBy(f => f.Titulo)
                    .Take(5)
                    .ToList();

                var filmesPorGenero =
                    from f in db.Filmes
                    group f by f.Genero into grupo
                    orderby grupo.Key
                    select new
                    {
                        Genero = grupo.Key,
                        Total = grupo.Count()
                    };

                using (StreamWriter sw = new StreamWriter(caminho, false))
                {
                    sw.WriteLine("Indicador;Valor");
                    sw.WriteLine("Total de filmes;" + totalFilmes);
                    sw.WriteLine("Total gasto;" + totalGasto.ToString("0.00"));
                    sw.WriteLine("Orçamento mensal;" + valorOrcamento.ToString("0.00"));
                    sw.WriteLine("Saldo disponível;" + saldo.ToString("0.00"));
                    sw.WriteLine("Preço médio;" + precoMedio.ToString("0.00"));

                    if (melhorIMDb != null)
                    {
                        sw.WriteLine("Melhor IMDb;" + EscaparCsv(melhorIMDb.Titulo) + " (" + melhorIMDb.NotaIMDb.ToString("0.0") + ")");
                    }
                    else
                    {
                        sw.WriteLine("Melhor IMDb;sem dados");
                    }

                    sw.WriteLine();
                    sw.WriteLine("Top filmes mais vistos");
                    sw.WriteLine("Título;Visualizações");

                    foreach (Filmecs f in topFilmes)
                    {
                        sw.WriteLine(EscaparCsv(f.Titulo) + ";" + f.VezesVisto);
                    }

                    sw.WriteLine();
                    sw.WriteLine("Filmes por género");
                    sw.WriteLine("Género;Total");

                    foreach (var item in filmesPorGenero.ToList())
                    {
                        sw.WriteLine(EscaparCsv(item.Genero) + ";" + item.Total);
                    }
                }
            }
        }

        private string EscaparCsv(string valor)
        {
            if (valor == null)
            {
                return "";
            }

            if (valor.Contains(";") || valor.Contains("\""))
            {
                return "\"" + valor.Replace("\"", "\"\"") + "\"";
            }

            return valor;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}