using CineDBteste.Model;
using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace CineDBteste
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.RowHeadersWidth = 60;
            AtualizarGrelha();
            dataGridView1.ClearSelection();
        }

        private void AtualizarGrelha()
        {
            using (CinemaContext db = new CinemaContext())
            {
                dataGridView1.DataSource = db.Filmes
                    .OrderBy(f => f.Titulo)
                    .ToList();
            }

            if (dataGridView1.Columns["DataHoraAlteracao"] != null)
            {
                dataGridView1.Columns["DataHoraAlteracao"].HeaderText = "Data / Hora da alteração";
                dataGridView1.Columns["DataHoraAlteracao"].DefaultCellStyle.Format = "dd/MM/yyyy HH:mm:ss";
            }

            if (dataGridView1.Columns["AlteradoPor"] != null)
            {
                dataGridView1.Columns["AlteradoPor"].HeaderText = "Alterado por";
            }

            if (dataGridView1.Columns["VezesVisto"] != null)
            {
                dataGridView1.Columns["VezesVisto"].HeaderText = "N.º de visualizações";
            }
        }

        private void LimparCampos()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            dataGridView1.ClearSelection();
        }

        private bool ValidarDados(out int ano, out int vezesVisto)
        {
            ano = 0;
            vezesVisto = 0;

            if (textBox1.Text.Trim() == "" ||
                textBox2.Text.Trim() == "" ||
                textBox3.Text.Trim() == "" ||
                textBox5.Text.Trim() == "" ||
                textBox6.Text.Trim() == "")
            {
                MessageBox.Show("Preencha todos os campos.");
                return false;
            }

            if (!int.TryParse(textBox3.Text, out ano))
            {
                MessageBox.Show("O ano tem de ser numérico.");
                return false;
            }

            if (!int.TryParse(textBox5.Text, out vezesVisto))
            {
                MessageBox.Show("O número de visualizações tem de ser numérico.");
                return false;
            }

            if (vezesVisto < 0)
            {
                MessageBox.Show("O número de visualizações não pode ser negativo.");
                return false;
            }

            return true;
        }

        private bool FilmeRepetido(CinemaContext db, string titulo, string genero, int ano, string realizador, int? idIgnorar = null)
        {
            return db.Filmes.Any(f =>
                f.Titulo == titulo &&
                f.Genero == genero &&
                f.Ano == ano &&
                f.Realizador == realizador &&
                (!idIgnorar.HasValue || f.Id != idIgnorar.Value));
        }

        private void button1Adicionar_Click(object sender, EventArgs e)
        {
            int ano;
            int vezesVisto;

            if (!ValidarDados(out ano, out vezesVisto))
            {
                return;
            }

            string titulo = textBox1.Text.Trim();
            string genero = textBox2.Text.Trim();
            string realizador = textBox6.Text.Trim();

            using (CinemaContext db = new CinemaContext())
            {
                if (FilmeRepetido(db, titulo, genero, ano, realizador))
                {
                    MessageBox.Show("Este filme já existe na base de dados.");
                    return;
                }

                Filmecs filme = new Filmecs
                {
                    Titulo = titulo,
                    Genero = genero,
                    Ano = ano,
                    Realizador = realizador,
                    VezesVisto = vezesVisto,
                    DataHoraAlteracao = DateTime.Now,
                    AlteradoPor = Sessao.UtilizadorAtual
                };

                db.Filmes.Add(filme);
                db.SaveChanges();
            }

            MessageBox.Show("Filme guardado com sucesso.");
            AtualizarGrelha();
            LimparCampos();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null && dataGridView1.CurrentRow.DataBoundItem != null)
            {
                Filmecs filmeSelecionado = (Filmecs)dataGridView1.CurrentRow.DataBoundItem;

                textBox4.Text = filmeSelecionado.Id.ToString();
                textBox1.Text = filmeSelecionado.Titulo;
                textBox2.Text = filmeSelecionado.Genero;
                textBox3.Text = filmeSelecionado.Ano.ToString();
                textBox5.Text = filmeSelecionado.VezesVisto.ToString();
                textBox6.Text = filmeSelecionado.Realizador;
            }
        }

        private void button1Remover_Click(object sender, EventArgs e)
        {
            if (textBox4.Text.Trim() == "")
            {
                MessageBox.Show("Indique o ID do filme.");
                return;
            }

            int id;
            if (!int.TryParse(textBox4.Text, out id))
            {
                MessageBox.Show("O ID tem de ser numérico.");
                return;
            }

            using (CinemaContext db = new CinemaContext())
            {
                Filmecs filme = db.Filmes.Find(id);

                if (filme == null)
                {
                    MessageBox.Show("Não existe nenhum filme com esse ID.");
                    return;
                }

                db.Filmes.Remove(filme);
                db.SaveChanges();
            }

            MessageBox.Show("Filme eliminado com sucesso.");
            AtualizarGrelha();
            LimparCampos();
        }

        private void button1Editar_Click(object sender, EventArgs e)
        {
            if (textBox4.Text.Trim() == "")
            {
                MessageBox.Show("Indique o ID do filme.");
                return;
            }

            int id;
            if (!int.TryParse(textBox4.Text, out id))
            {
                MessageBox.Show("O ID tem de ser numérico.");
                return;
            }

            int ano;
            int vezesVisto;

            if (!ValidarDados(out ano, out vezesVisto))
            {
                return;
            }

            string titulo = textBox1.Text.Trim();
            string genero = textBox2.Text.Trim();
            string realizador = textBox6.Text.Trim();

            using (CinemaContext db = new CinemaContext())
            {
                Filmecs filme = db.Filmes.Find(id);

                if (filme == null)
                {
                    MessageBox.Show("Não existe nenhum filme com esse ID.");
                    return;
                }

                if (FilmeRepetido(db, titulo, genero, ano, realizador, id))
                {
                    MessageBox.Show("Já existe outro filme com os mesmos dados.");
                    return;
                }

                filme.Titulo = titulo;
                filme.Genero = genero;
                filme.Ano = ano;
                filme.Realizador = realizador;
                filme.VezesVisto = vezesVisto;
                filme.DataHoraAlteracao = DateTime.Now;
                filme.AlteradoPor = Sessao.UtilizadorAtual;

                db.SaveChanges();
            }

            MessageBox.Show("Filme atualizado com sucesso.");
            AtualizarGrelha();
            LimparCampos();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Ficheiros CSV (*.csv)|*.csv";
            sfd.Title = "Guardar ficheiro CSV";
            sfd.FileName = "filmes.csv";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                ExportarCsv(sfd.FileName);
                MessageBox.Show("Ficheiro CSV exportado com sucesso.");
            }
        }

        private void ExportarCsv(string caminho)
        {
            using (CinemaContext db = new CinemaContext())
            {
                var filmes = db.Filmes
                    .OrderBy(f => f.Id)
                    .ToList();

                using (StreamWriter sw = new StreamWriter(caminho, false))
                {
                    sw.WriteLine("Id;Titulo;Genero;Ano;Realizador;DataHoraAlteracao;AlteradoPor;VezesVisto");

                    foreach (Filmecs f in filmes)
                    {
                        string dataHora = "";

                        if (f.DataHoraAlteracao.HasValue)
                        {
                            dataHora = f.DataHoraAlteracao.Value.ToString("dd/MM/yyyy HH:mm:ss");
                        }

                        sw.WriteLine(
                            f.Id + ";" +
                            EscaparCsv(f.Titulo) + ";" +
                            EscaparCsv(f.Genero) + ";" +
                            f.Ano + ";" +
                            EscaparCsv(f.Realizador) + ";" +
                            dataHora + ";" +
                            EscaparCsv(f.AlteradoPor) + ";" +
                            f.VezesVisto
                        );
                    }
                }
            }
        }

        private string EscaparCsv(string valor)
        {
            if (valor == null)
            {
                return "";
            }

            if (valor.Contains(";") || valor.Contains("\""))
            {
                return "\"" + valor.Replace("\"", "\"\"") + "\"";
            }

            return valor;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            string numero = (e.RowIndex + 1).ToString();
            dataGridView1.Rows[e.RowIndex].HeaderCell.Value = numero;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.ShowDialog();

            AtualizarGrelha();
            dataGridView1.ClearSelection();
        }
    }
}