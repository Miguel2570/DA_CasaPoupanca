using CineDBteste;
using CineDBteste.Model;
using System;
using System.Data.Entity;
using System.Windows.Forms;

namespace CineDB
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Database.SetInitializer(new AppDbInitializer());
            using (CinemaContext db = new CinemaContext())
            {
                db.Database.Initialize(false);
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);


            using (Form2 login = new Form2())
            {
                if (login.ShowDialog() == DialogResult.OK)
                {
                    Application.Run(new Form1());
                }
                //ApplicationConfiguration.Initialize();
                //Application.Run(new Form1());
            }
        }
    }
}