﻿namespace CineDBteste
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPrecoCompra = new TextBox();
            txtIMDb = new TextBox();
            dtpDataCompra = new DateTimePicker();
            txtMes = new TextBox();
            txtAnoOrcamento = new TextBox();
            txtValorOrcamento = new TextBox();
            btnGuardarCompra = new Button();
            button1 = new Button();
            btnAtualizarEstatisticas = new Button();
            btnFechar = new Button();
            dgvCompras = new DataGridView();
            lstTopFilmes = new ListBox();
            lstFilmesPorGenero = new ListBox();
            lblTotalFilmes = new Label();
            lblTotalGasto = new Label();
            lblSaldo = new Label();
            lblPrecoMedio = new Label();
            blMelhorIMDb = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            txtNomeFilme = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvCompras).BeginInit();
            SuspendLayout();
            // 
            // txtPrecoCompra
            // 
            txtPrecoCompra.Location = new Point(249, 128);
            txtPrecoCompra.Margin = new Padding(4, 4, 4, 4);
            txtPrecoCompra.Name = "txtPrecoCompra";
            txtPrecoCompra.Size = new Size(375, 31);
            txtPrecoCompra.TabIndex = 1;
            // 
            // txtIMDb
            // 
            txtIMDb.Location = new Point(249, 70);
            txtIMDb.Margin = new Padding(4, 4, 4, 4);
            txtIMDb.Name = "txtIMDb";
            txtIMDb.Size = new Size(375, 31);
            txtIMDb.TabIndex = 2;
            // 
            // dtpDataCompra
            // 
            dtpDataCompra.Location = new Point(249, 180);
            dtpDataCompra.Margin = new Padding(4, 4, 4, 4);
            dtpDataCompra.Name = "dtpDataCompra";
            dtpDataCompra.Size = new Size(375, 31);
            dtpDataCompra.TabIndex = 3;
            // 
            // txtMes
            // 
            txtMes.Location = new Point(249, 360);
            txtMes.Margin = new Padding(4, 4, 4, 4);
            txtMes.Name = "txtMes";
            txtMes.Size = new Size(155, 31);
            txtMes.TabIndex = 4;
            // 
            // txtAnoOrcamento
            // 
            txtAnoOrcamento.Location = new Point(249, 298);
            txtAnoOrcamento.Margin = new Padding(4, 4, 4, 4);
            txtAnoOrcamento.Name = "txtAnoOrcamento";
            txtAnoOrcamento.Size = new Size(155, 31);
            txtAnoOrcamento.TabIndex = 5;
            // 
            // txtValorOrcamento
            // 
            txtValorOrcamento.Location = new Point(249, 428);
            txtValorOrcamento.Margin = new Padding(4, 4, 4, 4);
            txtValorOrcamento.Name = "txtValorOrcamento";
            txtValorOrcamento.Size = new Size(155, 31);
            txtValorOrcamento.TabIndex = 6;
            // 
            // btnGuardarCompra
            // 
            btnGuardarCompra.Location = new Point(426, 242);
            btnGuardarCompra.Margin = new Padding(4, 4, 4, 4);
            btnGuardarCompra.Name = "btnGuardarCompra";
            btnGuardarCompra.Size = new Size(199, 36);
            btnGuardarCompra.TabIndex = 7;
            btnGuardarCompra.Text = "Guardar compra";
            btnGuardarCompra.UseVisualStyleBackColor = true;
            btnGuardarCompra.Click += btnGuardarCompra_Click;
            // 
            // button1
            // 
            button1.Location = new Point(426, 455);
            button1.Margin = new Padding(4, 4, 4, 4);
            button1.Name = "button1";
            button1.Size = new Size(199, 36);
            button1.TabIndex = 8;
            button1.Text = "Guardar orçamento";
            button1.TextAlign = ContentAlignment.BottomCenter;
            button1.UseVisualStyleBackColor = true;
            button1.Click += btnGuardarOrcamento_Click;
            // 
            // btnAtualizarEstatisticas
            // 
            btnAtualizarEstatisticas.Location = new Point(1176, 632);
            btnAtualizarEstatisticas.Margin = new Padding(4, 4, 4, 4);
            btnAtualizarEstatisticas.Name = "btnAtualizarEstatisticas";
            btnAtualizarEstatisticas.Size = new Size(288, 36);
            btnAtualizarEstatisticas.TabIndex = 9;
            btnAtualizarEstatisticas.Text = "Guardar estatística";
            btnAtualizarEstatisticas.UseVisualStyleBackColor = true;
            btnAtualizarEstatisticas.Click += btnAtualizarEstatisticas_Click;
            // 
            // btnFechar
            // 
            btnFechar.Location = new Point(1039, 698);
            btnFechar.Margin = new Padding(4, 4, 4, 4);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(284, 36);
            btnFechar.TabIndex = 10;
            btnFechar.Text = "Fechar";
            btnFechar.UseVisualStyleBackColor = true;
            btnFechar.Click += btnFechar_Click;
            // 
            // dgvCompras
            // 
            dgvCompras.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCompras.Location = new Point(689, 70);
            dgvCompras.Margin = new Padding(4, 4, 4, 4);
            dgvCompras.Name = "dgvCompras";
            dgvCompras.RowHeadersWidth = 51;
            dgvCompras.Size = new Size(856, 332);
            dgvCompras.TabIndex = 11;
            // 
            // lstTopFilmes
            // 
            lstTopFilmes.FormattingEnabled = true;
            lstTopFilmes.ItemHeight = 25;
            lstTopFilmes.Location = new Point(249, 516);
            lstTopFilmes.Margin = new Padding(4, 4, 4, 4);
            lstTopFilmes.Name = "lstTopFilmes";
            lstTopFilmes.Size = new Size(375, 129);
            lstTopFilmes.TabIndex = 12;
            // 
            // lstFilmesPorGenero
            // 
            lstFilmesPorGenero.FormattingEnabled = true;
            lstFilmesPorGenero.ItemHeight = 25;
            lstFilmesPorGenero.Location = new Point(249, 656);
            lstFilmesPorGenero.Margin = new Padding(4, 4, 4, 4);
            lstFilmesPorGenero.Name = "lstFilmesPorGenero";
            lstFilmesPorGenero.Size = new Size(375, 129);
            lstFilmesPorGenero.TabIndex = 13;
            // 
            // lblTotalFilmes
            // 
            lblTotalFilmes.AutoSize = true;
            lblTotalFilmes.Location = new Point(65, 516);
            lblTotalFilmes.Margin = new Padding(4, 0, 4, 0);
            lblTotalFilmes.Name = "lblTotalFilmes";
            lblTotalFilmes.Size = new Size(130, 25);
            lblTotalFilmes.TabIndex = 14;
            lblTotalFilmes.Text = "Total de filmes:";
            // 
            // lblTotalGasto
            // 
            lblTotalGasto.AutoSize = true;
            lblTotalGasto.Location = new Point(690, 586);
            lblTotalGasto.Margin = new Padding(4, 0, 4, 0);
            lblTotalGasto.Name = "lblTotalGasto";
            lblTotalGasto.Size = new Size(206, 25);
            lblTotalGasto.TabIndex = 15;
            lblTotalGasto.Text = "Total do gasto efetuado:";
            // 
            // lblSaldo
            // 
            lblSaldo.AutoSize = true;
            lblSaldo.Location = new Point(690, 536);
            lblSaldo.Margin = new Padding(4, 0, 4, 0);
            lblSaldo.Name = "lblSaldo";
            lblSaldo.Size = new Size(61, 25);
            lblSaldo.TabIndex = 16;
            lblSaldo.Text = "Saldo:";
            // 
            // lblPrecoMedio
            // 
            lblPrecoMedio.AutoSize = true;
            lblPrecoMedio.Location = new Point(690, 485);
            lblPrecoMedio.Margin = new Padding(4, 0, 4, 0);
            lblPrecoMedio.Name = "lblPrecoMedio";
            lblPrecoMedio.Size = new Size(116, 25);
            lblPrecoMedio.TabIndex = 17;
            lblPrecoMedio.Text = "Preço médio:";
            // 
            // blMelhorIMDb
            // 
            blMelhorIMDb.AutoSize = true;
            blMelhorIMDb.Location = new Point(685, 436);
            blMelhorIMDb.Margin = new Padding(4, 0, 4, 0);
            blMelhorIMDb.Name = "blMelhorIMDb";
            blMelhorIMDb.Size = new Size(122, 25);
            blMelhorIMDb.TabIndex = 18;
            blMelhorIMDb.Text = "Melhor IMDb:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(31, 19);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(136, 25);
            label1.TabIndex = 19;
            label1.Text = "Nome do filme:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(31, 128);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(151, 25);
            label2.TabIndex = 20;
            label2.Text = "Preço da compra:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(31, 70);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(192, 25);
            label3.TabIndex = 21;
            label3.Text = "Classificação do IMDb:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(31, 186);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(144, 25);
            label4.TabIndex = 22;
            label4.Text = "Data da compra:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(31, 364);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(167, 25);
            label5.TabIndex = 23;
            label5.Text = "Mês do orçamento:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(31, 298);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(167, 25);
            label6.TabIndex = 24;
            label6.Text = "Ano do orçamento:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(31, 428);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(166, 25);
            label7.TabIndex = 25;
            label7.Text = "Orçamento mensal:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(6, 656);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(224, 25);
            label8.TabIndex = 26;
            label8.Text = "Total de filmes por género:";
            // 
            // txtNomeFilme
            // 
            txtNomeFilme.Location = new Point(249, 19);
            txtNomeFilme.Margin = new Padding(4, 4, 4, 4);
            txtNomeFilme.Name = "txtNomeFilme";
            txtNomeFilme.Size = new Size(375, 31);
            txtNomeFilme.TabIndex = 27;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1560, 804);
            Controls.Add(txtNomeFilme);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(blMelhorIMDb);
            Controls.Add(lblPrecoMedio);
            Controls.Add(lblSaldo);
            Controls.Add(lblTotalGasto);
            Controls.Add(lblTotalFilmes);
            Controls.Add(lstFilmesPorGenero);
            Controls.Add(lstTopFilmes);
            Controls.Add(dgvCompras);
            Controls.Add(btnFechar);
            Controls.Add(btnAtualizarEstatisticas);
            Controls.Add(button1);
            Controls.Add(btnGuardarCompra);
            Controls.Add(txtValorOrcamento);
            Controls.Add(txtAnoOrcamento);
            Controls.Add(txtMes);
            Controls.Add(dtpDataCompra);
            Controls.Add(txtIMDb);
            Controls.Add(txtPrecoCompra);
            Margin = new Padding(4, 4, 4, 4);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            ((System.ComponentModel.ISupportInitialize)dgvCompras).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtPrecoCompra;
        private TextBox txtIMDb;
        private DateTimePicker dtpDataCompra;
        private TextBox txtMes;
        private TextBox txtAnoOrcamento;
        private TextBox txtValorOrcamento;
        private Button btnGuardarCompra;
        private Button button1;
        private Button btnAtualizarEstatisticas;
        private Button btnFechar;
        private DataGridView dgvCompras;
        private ListBox lstTopFilmes;
        private ListBox lstFilmesPorGenero;
        private Label lblTotalFilmes;
        private Label lblTotalGasto;
        private Label lblSaldo;
        private Label lblPrecoMedio;
        private Label blMelhorIMDb;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox txtNomeFilme;
    }
}