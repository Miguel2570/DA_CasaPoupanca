﻿namespace CineDBteste
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            textBox1Username = new TextBox();
            textBox1Password = new TextBox();
            button1Entrar = new Button();
            button2Cancelar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(71, 63);
            label1.Name = "label1";
            label1.Size = new Size(78, 20);
            label1.TabIndex = 0;
            label1.Text = "Username:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(77, 117);
            label2.Name = "label2";
            label2.Size = new Size(73, 20);
            label2.TabIndex = 1;
            label2.Text = "Password:";
            // 
            // textBox1Username
            // 
            textBox1Username.Location = new Point(181, 60);
            textBox1Username.Name = "textBox1Username";
            textBox1Username.Size = new Size(280, 27);
            textBox1Username.TabIndex = 2;
            // 
            // textBox1Password
            // 
            textBox1Password.Location = new Point(181, 117);
            textBox1Password.Name = "textBox1Password";
            textBox1Password.Size = new Size(280, 27);
            textBox1Password.TabIndex = 3;
            // 
            // button1Entrar
            // 
            button1Entrar.Location = new Point(181, 168);
            button1Entrar.Name = "button1Entrar";
            button1Entrar.Size = new Size(136, 29);
            button1Entrar.TabIndex = 4;
            button1Entrar.Text = "Entrar";
            button1Entrar.UseVisualStyleBackColor = true;
            button1Entrar.Click += button1Entrar_Click;
            // 
            // button2Cancelar
            // 
            button2Cancelar.Location = new Point(323, 168);
            button2Cancelar.Name = "button2Cancelar";
            button2Cancelar.Size = new Size(138, 29);
            button2Cancelar.TabIndex = 5;
            button2Cancelar.Text = "Cancelar";
            button2Cancelar.UseVisualStyleBackColor = true;
            button2Cancelar.Click += button2Cancelar_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(506, 224);
            Controls.Add(button2Cancelar);
            Controls.Add(button1Entrar);
            Controls.Add(textBox1Password);
            Controls.Add(textBox1Username);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox textBox1Username;
        private TextBox textBox1Password;
        private Button button1Entrar;
        private Button button2Cancelar;
    }
}