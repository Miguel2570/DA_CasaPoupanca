﻿namespace CineDBteste
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1Titulo = new Label();
            label1Genero = new Label();
            label2Ano = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            button1Adicionar = new Button();
            button1Editar = new Button();
            button1Remover = new Button();
            dataGridView1 = new DataGridView();
            label1 = new Label();
            textBox4 = new TextBox();
            label2 = new Label();
            textBox5 = new TextBox();
            button2 = new Button();
            button3 = new Button();
            label3 = new Label();
            textBox6 = new TextBox();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1Titulo
            // 
            label1Titulo.AutoSize = true;
            label1Titulo.Location = new Point(29, 45);
            label1Titulo.Margin = new Padding(4, 0, 4, 0);
            label1Titulo.Name = "label1Titulo";
            label1Titulo.Size = new Size(134, 25);
            label1Titulo.TabIndex = 0;
            label1Titulo.Text = "Titulo do Filme:";
            // 
            // label1Genero
            // 
            label1Genero.AutoSize = true;
            label1Genero.Location = new Point(29, 95);
            label1Genero.Margin = new Padding(4, 0, 4, 0);
            label1Genero.Name = "label1Genero";
            label1Genero.Size = new Size(144, 25);
            label1Genero.TabIndex = 1;
            label1Genero.Text = "Género do filme:";
            // 
            // label2Ano
            // 
            label2Ano.AutoSize = true;
            label2Ano.Location = new Point(29, 150);
            label2Ano.Margin = new Padding(4, 0, 4, 0);
            label2Ano.Name = "label2Ano";
            label2Ano.Size = new Size(49, 25);
            label2Ano.TabIndex = 2;
            label2Ano.Text = "Ano:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(199, 41);
            textBox1.Margin = new Padding(4, 4, 4, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(543, 31);
            textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(200, 95);
            textBox2.Margin = new Padding(4, 4, 4, 4);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(103, 31);
            textBox2.TabIndex = 4;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(202, 150);
            textBox3.Margin = new Padding(4, 4, 4, 4);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 31);
            textBox3.TabIndex = 5;
            // 
            // button1Adicionar
            // 
            button1Adicionar.Location = new Point(833, 38);
            button1Adicionar.Margin = new Padding(4, 4, 4, 4);
            button1Adicionar.Name = "button1Adicionar";
            button1Adicionar.Size = new Size(191, 36);
            button1Adicionar.TabIndex = 6;
            button1Adicionar.Text = "Adicionar";
            button1Adicionar.UseVisualStyleBackColor = true;
            button1Adicionar.Click += button1Adicionar_Click;
            // 
            // button1Editar
            // 
            button1Editar.Location = new Point(830, 154);
            button1Editar.Margin = new Padding(4, 4, 4, 4);
            button1Editar.Name = "button1Editar";
            button1Editar.Size = new Size(194, 36);
            button1Editar.TabIndex = 7;
            button1Editar.Text = "Atualizar";
            button1Editar.UseVisualStyleBackColor = true;
            button1Editar.Click += button1Editar_Click;
            // 
            // button1Remover
            // 
            button1Remover.Location = new Point(830, 96);
            button1Remover.Margin = new Padding(4, 4, 4, 4);
            button1Remover.Name = "button1Remover";
            button1Remover.Size = new Size(191, 36);
            button1Remover.TabIndex = 8;
            button1Remover.Text = "Remover";
            button1Remover.UseVisualStyleBackColor = true;
            button1Remover.Click += button1Remover_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(13, 227);
            dataGridView1.Margin = new Padding(4, 4, 4, 4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1306, 424);
            dataGridView1.TabIndex = 9;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(648, 100);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(32, 25);
            label1.TabIndex = 10;
            label1.Text = "Id:";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(686, 96);
            textBox4.Margin = new Padding(4, 4, 4, 4);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(55, 31);
            textBox4.TabIndex = 11;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(350, 99);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(143, 25);
            label2.TabIndex = 12;
            label2.Text = "Nº visualizações:";
            label2.Click += label2_Click;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(506, 96);
            textBox5.Margin = new Padding(4, 4, 4, 4);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(94, 31);
            textBox5.TabIndex = 13;
            // 
            // button2
            // 
            button2.Location = new Point(1057, 100);
            button2.Margin = new Padding(4, 4, 4, 4);
            button2.Name = "button2";
            button2.Size = new Size(215, 36);
            button2.TabIndex = 15;
            button2.Text = "Exportar CSV";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(1057, 154);
            button3.Margin = new Padding(4, 4, 4, 4);
            button3.Name = "button3";
            button3.Size = new Size(215, 36);
            button3.TabIndex = 16;
            button3.Text = "Sair";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(350, 154);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(97, 25);
            label3.TabIndex = 18;
            label3.Text = "Realizador:";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(461, 150);
            textBox6.Margin = new Padding(4, 4, 4, 4);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(280, 31);
            textBox6.TabIndex = 19;
            // 
            // button1
            // 
            button1.Location = new Point(1057, 40);
            button1.Margin = new Padding(4, 4, 4, 4);
            button1.Name = "button1";
            button1.Size = new Size(215, 36);
            button1.TabIndex = 20;
            button1.Text = "Compras e Estatisticas";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1395, 754);
            Controls.Add(button1);
            Controls.Add(textBox6);
            Controls.Add(label3);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(textBox5);
            Controls.Add(label2);
            Controls.Add(textBox4);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Controls.Add(button1Remover);
            Controls.Add(button1Editar);
            Controls.Add(button1Adicionar);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label2Ano);
            Controls.Add(label1Genero);
            Controls.Add(label1Titulo);
            Margin = new Padding(4, 4, 4, 4);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1Titulo;
        private Label label1Genero;
        private Label label2Ano;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private Button button1Adicionar;
        private Button button1Editar;
        private Button button1Remover;
        private DataGridView dataGridView1;
        private Label label1;
        private TextBox textBox4;
        private Label label2;
        private TextBox textBox5;
        private Button button2;
        private Button button3;
        private Label label3;
        private TextBox textBox6;
        private Button button1;
    }
}
